const books = [
    { id: 1, title: "The Great Gatsby", price: 10, img: "https://via.placeholder.com/100x150?text=Gatsby" },
    { id: 2, title: "1984", price: 12, img: "https://via.placeholder.com/100x150?text=1984" },
    { id: 3, title: "To Kill a Mockingbird", price: 15, img: "https://via.placeholder.com/100x150?text=Mockingbird" },
    { id: 4, title: "Moby Dick", price: 9, img: "https://via.placeholder.com/100x150?text=Moby+Dick" },
    { id: 5, title: "Pride and Prejudice", price: 11, img: "https://via.placeholder.com/100x150?text=Prejudice" },
    { id: 6, title: "War and Peace", price: 20, img: "https://via.placeholder.com/100x150?text=War+Peace" }
];

const cart = [];

function renderProducts() {
    const productList = document.getElementById("product-list");
    books.forEach(book => {
        const product = document.createElement("div");
        product.className = "product";
        product.innerHTML = `
            <img src="${book.img}" alt="${book.title}">
            <h3>${book.title}</h3>
            <p>$${book.price}</p>
            <button onclick="addToCart(${book.id})">Add to Cart</button>
        `;
        productList.appendChild(product);
    });
}

function addToCart(id) {
    const book = books.find(b => b.id === id);
    cart.push(book);
    document.getElementById("cart-count").innerText = cart.length;
}

document.getElementById("cart").addEventListener("click", () => {
    const modal = document.getElementById("cart-modal");
    modal.classList.remove("hidden");
    const items = document.getElementById("cart-items");
    items.innerHTML = '';
    cart.forEach(book => {
        const li = document.createElement("li");
        li.textContent = `${book.title} - $${book.price}`;
        items.appendChild(li);
    });
});

function closeCart() {
    document.getElementById("cart-modal").classList.add("hidden");
}

window.onload = renderProducts;
